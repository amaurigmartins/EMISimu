%% Coordinates files [X Y] in meters:

app.TargetCoordFile.Text ='D:\Mestrado\EMISimu\WCNPS2021\DT_WCNPS.csv';
app.SourceCoordFile.Text ='D:\Mestrado\EMISimu\WCNPS2021\LT_WCNPS.csv';