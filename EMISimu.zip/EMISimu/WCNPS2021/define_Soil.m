
% Soil Resistivity per section .csv file [ohm.m]:
app.SoilResistivityFile.Text = 'D:\Mestrado\EMISimu\WCNPS2021\soil_resistivity_data.csv';
